import { Component } from '@angular/core';

@Component({
  selector: 'app-report-layout',
  standalone: true,
  imports: [],
  templateUrl: './report-layout.component.html',
  styleUrl: './report-layout.component.css'
})
export class ReportLayoutComponent {

}
